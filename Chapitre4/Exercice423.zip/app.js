let user = {}
let dapp = {}


async function remettreDevoir(){
  let lienDevoir = document.getElementById("lienDevoir").value
  let hashLien = await dapp.Contrat.produireHash(lienDevoir);
  document.getElementById("hashDevoir").innerHTML = hashLien;
  dapp.ContratSigner.remettre(hashLien);
  document.getElementById("divCredibilite").className = 'visible'
}


async function getCredibilite(){
  let lienProprietaire = document.getElementById("lienProprietaire").value
  document.getElementById("credibiliteAssocie").innerHTML = await dapp.Contrat.cred(lienProprietaire);
}



async function connectMetamask() {
  try {
    const addresses = await ethereum.enable()
    user.address = addresses[0]

    const provider = new ethers.providers.Web3Provider(ethereum)
    let Contrat=new ethers.Contract(contractAddress, contractABI, provider)

    let ContratSigner=Contrat.connect(provider.getSigner(user.address))

    dapp = { provider, Contrat, ContratSigner}
    console.log("DApp ready: ", dapp)
    console.log("User ready: ", user)

    Contrat.on('Remettre', (emetteur, devoir, rang, nbCred) => {
      let message = "Adresse du dépositaire : " + emetteur + "<br />";
      message += "Hash du devoir : " + devoir + "<br />";
      message += "Rang : " + rang + " => " + nbCred + " Cred <br /><br />";
      document.getElementById("remettre").innerHTML += message;
    });

    provider.getNetwork().then(
      ntw => {
      console.log(ntw);
    }
    )

  } catch(err) {
    console.error(err);
  }
}
connectMetamask()

